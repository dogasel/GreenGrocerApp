import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class tester {

    // Database credentials
    private static final String DB_URL = "jdbc:mysql://localhost:3306/myGreenGrocer";
    private static final String DB_USER = "your_db_username";
    private static final String DB_PASSWORD = "your_db_password";

    public static void main(String[] args) {
        // Test database connection
        try {
            testDatabaseConnection();
            System.out.println("Database connection successful.");

            // Test user registration
            boolean isRegistered = registerNewUser("testuser", "testpassword");
            if (isRegistered) {
                System.out.println("User registration successful.");
            } else {
                System.out.println("User registration failed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void testDatabaseConnection() throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            System.out.println("Connected to the database successfully.");
        }
    }

    private static boolean registerNewUser(String username, String password) throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String checkUserSql = "SELECT COUNT(*) FROM users WHERE username = ?";
            try (PreparedStatement checkUserStmt = conn.prepareStatement(checkUserSql)) {
                checkUserStmt.setString(1, username);
                ResultSet resultSet = checkUserStmt.executeQuery();
                if (resultSet.next() && resultSet.getInt(1) > 0) {
                    return false; // Username already exists
                }
            }

            String insertSql = "INSERT INTO users (username, password) VALUES (?, ?)";
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setString(1, username);
                insertStmt.setString(2, password); // In a real application, hash the password
                insertStmt.executeUpdate();
                return true; // User registered successfully
            }
        }
    }
}
